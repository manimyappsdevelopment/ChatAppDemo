//
//  UserCell.swift
//  chatAppDemo
//
//  Created by Madhu Mekala on 21/3/18.
//  Copyright © 2018 chatAppDemo. All rights reserved.
//

import UIKit

class UserCell: BaseCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
